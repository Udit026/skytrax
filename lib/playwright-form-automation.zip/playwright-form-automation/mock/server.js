/**
 * Local mock form + dashboard so you can test before pointing at real URLs.
 * Start: npm run mock
 */
const http = require("http");
const PORT = 3456;

const formHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <title>Mock Office Form</title>
  <style>
    body{font-family:system-ui;max-width:560px;margin:40px auto;padding:0 16px}
    label{display:block;margin-top:14px;font-weight:600}
    input,select,textarea,button{width:100%;padding:8px;margin-top:4px;box-sizing:border-box}
    .row{display:flex;gap:12px;margin-top:6px} .row label{font-weight:400}
    button{margin-top:20px;background:#2563eb;color:#fff;border:0;cursor:pointer;padding:10px}
  </style>
</head>
<body>
  <h1>Mock Office Form</h1>
  <form method="POST" action="/submit">
    <label>Email <input type="email" name="email" required/></label>
    <label>Best place <input type="text" name="bestAirport"/></label>
    <label>Why best <textarea name="whyBest" rows="2"></textarea></label>
    <label>Typical use</label>
    <div class="row">
      <label><input type="radio" name="usage" value="Daily work"/> Daily work</label>
      <label><input type="radio" name="usage" value="Meetings"/> Meetings</label>
      <label><input type="radio" name="usage" value="Occasional visit"/> Occasional visit</label>
    </div>
    <label>Last used
      <select name="lastUsed">
        <option value="">—</option>
        <option value="in the last 1-2 months">in the last 1-2 months</option>
        <option value="in the last 3-6 months">in the last 3-6 months</option>
        <option value="in the last 12 months">in the last 12 months</option>
      </select>
    </label>
    <label>Country <input type="text" name="country"/></label>
    <label><input type="checkbox" name="terms" value="yes"/> I agree to the Terms</label>
    <button type="submit">Submit</button>
  </form>
</body>
</html>`;

const successHtml = `<!DOCTYPE html><html><body style="font-family:system-ui;margin:40px auto;max-width:480px">
<h1 style="color:green">Thank you!</h1><p>Submission received.</p><a href="/">Back</a>
</body></html>`;

const loginHtml = `<!DOCTYPE html><html><body style="font-family:system-ui;margin:40px auto;max-width:400px">
<h1>Dashboard Login</h1>
<form method="POST" action="/login">
  <label>Email <input type="email" name="email" style="width:100%;padding:8px"/></label><br/><br/>
  <label>Password <input type="password" name="password" style="width:100%;padding:8px"/></label><br/><br/>
  <button type="submit" style="padding:10px 20px">Login</button>
</form>
</body></html>`;

const uploadHtml = `<!DOCTYPE html><html><body style="font-family:system-ui;margin:40px auto;max-width:400px">
<h1>Upload Proof</h1>
<form method="POST" action="/upload" enctype="multipart/form-data">
  <label>Email <input type="email" name="email" style="width:100%;padding:8px" required/></label><br/><br/>
  <label>Screenshot <input type="file" name="screenshot" accept="image/*" required/></label><br/><br/>
  <button type="submit" style="padding:10px 20px;background:#059669;color:#fff;border:0">Save Submission</button>
</form>
</body></html>`;

const server = http.createServer((req, res) => {
  if (req.method === "GET" && req.url === "/") {
    res.writeHead(200, { "Content-Type": "text/html" });
    return res.end(formHtml);
  }
  if (req.method === "POST" && req.url === "/submit") {
    res.writeHead(200, { "Content-Type": "text/html" });
    return res.end(successHtml);
  }
  if (req.method === "GET" && (req.url === "/login" || req.url === "/dashboard/login")) {
    res.writeHead(200, { "Content-Type": "text/html" });
    return res.end(loginHtml);
  }
  if (req.method === "POST" && req.url === "/login") {
    res.writeHead(302, { Location: "/upload" });
    return res.end();
  }
  if (req.method === "GET" && req.url === "/upload") {
    res.writeHead(200, { "Content-Type": "text/html" });
    return res.end(uploadHtml);
  }
  if (req.method === "POST" && req.url === "/upload") {
    res.writeHead(200, { "Content-Type": "text/html" });
    return res.end(`<h1>Saved</h1><p>Proof received.</p><a href="/upload">Again</a>`);
  }
  res.writeHead(404);
  res.end("Not found");
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`Mock form:     http://127.0.0.1:${PORT}/`);
  console.log(`Mock login:    http://127.0.0.1:${PORT}/login`);
  console.log(`Mock upload:   http://127.0.0.1:${PORT}/upload`);
});
