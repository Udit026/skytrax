require("dotenv").config();
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const cfg = JSON.parse(
  fs.readFileSync(path.join(root, process.env.FLOW_CONFIG || "flow.config.json"), "utf8")
);

module.exports = {
  root,
  cfg,
  headless: process.env.HEADLESS === "true",
  env: process.env,
  abs: (p) => path.resolve(root, p),
};
