// const { chromium } = require("playwright");
// const { headless } = require("./config");

// async function openBrowser() {
//   const browser = await chromium.launch({
//     headless,
//     args: ["--disable-blink-features=AutomationControlled"],
//   });
//   const context = await browser.newContext({
//     viewport: { width: 1280, height: 900 },
//     userAgent:
//       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
//   });
//   // Individual actions may time out, but the flow wraps them in retry loops.
//   // A transient timeout therefore cannot end an automation run.
//   context.setDefaultTimeout(30000);
//   context.setDefaultNavigationTimeout(60000);
//   return { browser, context };
// }

// module.exports = { openBrowser };


const { chromium } = require("playwright");
const { headless } = require("./config");

/**
 * openBrowser()
 * - Browser launch karta hai
 * - Agar .env mein proxy set hai to saari traffic ProxyEmpire se jaati hai
 * - Agar proxy nahi hai to normal direct connection
 */
async function openBrowser() {
 
  const proxyServer = process.env.PROXY_SERVER; // http://host:port
  const proxyUser = process.env.PROXY_USER || undefined;
  const proxyPass = process.env.PROXY_PASS || undefined;

  // ----- 2) Launch options (browser process) -----
  const launchOptions = {
    headless, // true = background, false = visible window
    args: [
      // automation flag thoda kam obvious banane ke liye common flag
      "--disable-blink-features=AutomationControlled",
    ],
  };

  // ----- 3) Context options (har page isi context se) -----
  const contextOptions = {
    viewport: { width: 1280, height: 900 },
    userAgent:
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  };

  // ----- 4) Proxy tabhi lagao jab server diya ho -----
  if (proxyServer) {
    contextOptions.proxy = {
      server: proxyServer,     // "http://v2.proxyempire.io:5000"
      username: proxyUser,     // ProxyEmpire username
      password: proxyPass,     // ProxyEmpire password
      bypass: "skytrax-admin.vercel.app", // own dashboard goes direct, not via the metered proxy
    };
    console.log(`Proxy enabled → ${proxyServer}`);
  } else {
    console.log("Proxy not set → direct connection");
  }

  // ----- 5) Browser + context create -----
  const browser = await chromium.launch(launchOptions);
  const context = await browser.newContext(contextOptions);

  // Timeouts: ek action fail ho to flow retry use karta hai
  context.setDefaultTimeout(30000);          // 30s per action
  context.setDefaultNavigationTimeout(60000); // 60s page load

  return { browser, context };
}

module.exports = { openBrowser };