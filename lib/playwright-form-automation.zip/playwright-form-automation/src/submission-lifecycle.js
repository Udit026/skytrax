async function runConfirmedCycle({ submitMain, waitAfterSubmit, saveDashboard, markProcessed }) {
  const mainOutcome = await submitMain();
  if (mainOutcome?.status !== "confirmed") return mainOutcome || { status: "uncertain", reason: "missing_main_outcome" };
  await waitAfterSubmit();
  await saveDashboard();
  await markProcessed();
  return { status: "completed" };
}

async function runSelectedEmails(emails, processEmail) {
  for (const email of emails) await processEmail(email);
}

function selectEmailCandidates(users, { alreadyUsed, unconfirmed, currentEmail, emailOverride, limit }) {
  const used = new Set([...alreadyUsed, ...unconfirmed].map((email) => String(email).toLowerCase()));
  if (currentEmail) {
    const current = String(currentEmail).toLowerCase();
    const pending = users.filter((user) => user.email.toLowerCase() !== current && !used.has(user.email.toLowerCase()));
    return [{ email: currentEmail }, ...pending].slice(0, limit);
  }
  if (emailOverride) {
    const match = users.find((user) => user.email.toLowerCase() === emailOverride.toLowerCase());
    return match && !used.has(match.email.toLowerCase()) ? [match] : [];
  }
  return users.filter((user) => !used.has(user.email.toLowerCase())).slice(0, limit);
}

module.exports = { runConfirmedCycle, runSelectedEmails, selectEmailCandidates };
