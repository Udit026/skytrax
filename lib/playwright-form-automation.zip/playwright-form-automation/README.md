# Flexible Playwright Form Automation

Fill any form from a reusable **answers template**, take a screenshot, optionally submit, then upload the proof to your own dashboard.

Designed so you can swap the template and form later without rewriting code.

---

## 1. Install

```bash
npm install
npx playwright install chromium
cp .env.example .env
```

`.env` already has your dashboard credentials:

```
DASH_USER=admin@gmail.com
DASH_PASS=Devixopass185
```

---

## 2. What you need to fill in

### A. `flow.config.json`

| Key | What to put |
|-----|-------------|
| `form.url` | Your form URL |
| `form.emailSelector` | CSS selector of the email input |
| `form.fields` | Map of logical name → `{ selector, type }` |
| `form.submitSelector` | Submit button selector |
| `form.screenshot.elementSelector` | (optional) area to capture (email + submit) |
| `dashboard.uploadUrl` | Your upload page URL |
| `dashboard.login.url` | Your dashboard login page URL |

### B. `data/answers.template.json`

Drop your full template here. Supported `answer_type`s:

- `fixed` – always uses `"answer"`
- `random` – picks from `answer_pool.answers` (respects `unique_per_submission`)
- `dropdown` / `radio` – picks from `options`
- `dynamic` – left for the flow (email)

You can also give each question a `"fieldKey"` so it matches the keys in `form.fields`.

### C. `data/emails.csv`

One email per line (header optional).

---

## 3. Discover selectors on your form

```bash
npm run inspect -- https://your-form-url
```

This prints a table of every input/select/button and saves `screenshots/inspection.png`.  
Copy the selectors into `flow.config.json`.

---

## 4. Test the answer resolver

```bash
npm run resolve
```

Shows the concrete values that will be used for one submission (random picks change each time).

---

## 5. Run

### Fill and submit one form

The one-form flow processes pending CSV emails sequentially. For each email it fills the main form, captures the screenshot crop around the email field and submit button, submits the main form, waits 30 seconds, then opens your dashboard form. It fills the same email, attaches that screenshot, and fills any extra fields from the dashboard template. It clicks the dashboard save button before marking the email processed and moving to the next CSV email.

```bash
npm run fill -- --url "https://your-form-url" --template "data/answers.template.json"
```

Screenshots are saved as `screenshots/<email>_filled.png`. Emails are read in CSV order, and duplicate addresses are ignored case-insensitively. Each selected email is recorded in `data/used-emails.json` before filling, so it will never be selected again in a later cycle, even if filling fails or you use `--dry`. A `--email` override must also be present in the CSV. Completed cycles are recorded in `data/processed.json`; the active email and stage are saved in `data/flow-progress.json` so a restart resumes that email before selecting another. When no unused CSV emails remain, the command reports that and the total number of unique emails used. Use `--dry` to fill and capture screenshots without submitting. Use `--limit 1` to process only one email or choose a screenshot name with `--screenshot` (the email identifier is added to avoid overwriting):

```bash
npm run fill -- --url "https://your-form-url" --template "data/my-form.json" --email "you@example.com" --screenshot "screenshots/my-form.png" --dry
```

This mode first matches template `question`/`fieldKey` text to accessible form labels, then tries matching field names, IDs, placeholders, and ARIA labels. For reliable filling, questions should match the form's labels. Each action has a 30-second timeout and navigation has a 60-second timeout; failures are logged and retried indefinitely every five seconds, with progress messages while an action is waiting. The current email and stage are checkpointed so restarting resumes the active cycle. Stop the process with Ctrl+C. A 30-second wait follows the main form submission and each completed cycle; after every 100 completed cycles, the between-cycle wait is 60 seconds. Add selectors for any fields that don’t match under `form.fields` or `dashboard.fields`. Every site structures forms differently, so a JSON template and URL alone cannot guarantee that arbitrary forms will map correctly.

### Dashboard form settings

Set the full dashboard upload URL, including its domain and `/upload` path, in `dashboard.uploadUrl` in `flow.config.json` (for example, `https://your-dashboard.example/upload`). Set the full login page URL in `dashboard.login.url` and its email, password, and submit selectors in the same block. Put the dashboard login credentials in `.env` as `DASH_USER` and `DASH_PASS`. The main form needs no credentials when `form.login` is `null`.

The dashboard descriptor and optional answers are in `data/dashboard.template.json`; it supports the `url`, `login`, `fields`, and `submit` structure you provided. The email and screenshot values come from the CSV and generated screenshot. Optional dashboard answers can be added under `questions`; their selectors are read from the corresponding entries in `fields`. The one-form flow checks dashboard URL, login, selectors, credentials, and template before it starts, so missing settings will not submit the main form.

If the URL and template path are already set in `flow.config.json`, run `npm run fill`. Existing batch mode remains available below.

```bash
# Dry run – fills + screenshot, does NOT click Submit
npm run dry

# Process only the next 1 pending email
npm run run -- --limit 1

# Process everything pending
npm run run
```

Already-done emails are stored in `data/processed.json`.

---

## 6. Local mock (optional)

```bash
npm run mock          # terminal 1 – local form on :3456
npm run test:mock     # terminal 2 – quick smoke test
```

---

## Flexible template examples

**Simple fixed fields**

```json
{
  "questions": [
    { "fieldKey": "name", "answer_type": "fixed", "answer": "John" },
    { "fieldKey": "city", "answer_type": "fixed", "answer": "Delhi" }
  ]
}
```

**Random reason that stays unique across submissions**

```json
{
  "fieldKey": "whyBest",
  "answer_type": "random",
  "selection": { "unique_per_submission": true },
  "answer_pool": {
    "answers": ["Clean", "Fast service", "Friendly staff", "Modern design"]
  }
}
```

**Many rating questions at once**

In the template:

```json
{
  "section_instruction": "Ratings",
  "questions": [
    { "question_id": 5, "answer_type": "fixed", "answer": "5" },
    { "question_id": 6, "answer_type": "fixed", "answer": "5" }
  ]
}
```

In `flow.config.json` the `ratingFields` block will apply them using the pattern `input[name='rating_{id}']`.

---

## Flow summary (one email)

1. Resolve answers from the template (fresh random picks)
2. Open form → fill email + all mapped fields
3. Screenshot (full page or the element you configured)
4. Click Submit (skipped in `--dry`)
5. Login to dashboard (once per run) → upload email + screenshot
6. Mark email processed → next

---

Only use this on forms and dashboards you own or have permission to automate.
