# Checkpoint guard fix

## What was broken
`data/flow-progress.json` had:
- currentEmail: baljeet.chahal1690@gmail.com
- stage: main_submit_unconfirmed
- mainSurveyHttpStatus: 403

Startup code threw:
```
An unresolved main-survey submission is checkpointed. Batch halted...
```
So the browser never launched and no new CSV email was picked.

## What changed
1. **Startup guard is soft recovery**, not a hard stop.
   - Blocked email is written to `data/unconfirmed-emails.json`
   - Checkpoint is cleared (`stage: next`, status cleared)
   - Run continues with the next available email

2. **Main-survey 403 / uncertain / rejected** no longer halts the whole batch.
   - Email is skipped, evidence saved, next email continues
   - Only **Ctrl+C** stops the process

3. **Gaps (already in place)**
   - After every completed cycle: **30 seconds**
   - After every **100** completed cycles: **60 seconds**

4. **Resume**
   - If stage is `dashboard` / `main_submit_started` / `dashboard_saved`, it resumes that step
   - Does not re-submit main form unnecessarily when already past that stage

## How to run
```bash
# Correct way to pass limit (note the extra --)
npm run fill -- --limit 2

# Or call node directly
node src/flow.js --single --limit 2

# Full batch
npm run run
# or
node src/flow.js --single
```

## If it ever gets stuck again
You can manually clear the block:
```json
// data/flow-progress.json
{
  "completedCycles": <keep your number>,
  "currentEmail": null,
  "stage": "next",
  "screenshotPath": null,
  "waitUntil": null,
  "mainSurveyHttpStatus": null
}
```
Or just re-run — the soft recovery will clear it automatically.
