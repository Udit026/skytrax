const VALUE_OPTIONS = new Set(["--url", "--template", "--screenshot", "--email", "--limit"]);
const FLAG_OPTIONS = new Set(["--single", "--dry"]);

function parseFlowArgs(argv) {
  const flags = new Set();
  const values = new Map();
  const positional = [];

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!arg.startsWith("--")) {
      positional.push(arg);
      continue;
    }

    const equalsAt = arg.indexOf("=");
    const name = equalsAt < 0 ? arg : arg.slice(0, equalsAt);
    if (FLAG_OPTIONS.has(name)) {
      if (equalsAt >= 0) throw new Error(`${name} does not take a value.`);
      flags.add(name);
      continue;
    }
    if (!VALUE_OPTIONS.has(name)) throw new Error(`Unsupported option: ${name}`);

    const value = equalsAt >= 0 ? arg.slice(equalsAt + 1) : argv[++i];
    if (value === undefined || value === "" || value.startsWith("--")) {
      throw new Error(`${name} requires a value.`);
    }
    values.set(name, value);
  }

  if (positional.length) {
    throw new Error(`Unexpected positional argument "${positional[0]}". Use --limit N to limit this run.`);
  }

  let limit = Infinity;
  if (values.has("--limit")) {
    limit = Number(values.get("--limit"));
    if (!Number.isSafeInteger(limit) || limit < 1) {
      throw new Error("--limit must be a positive whole number.");
    }
  }

  const url = values.get("--url");
  const template = values.get("--template");
  const email = values.get("--email");
  return {
    dry: flags.has("--dry"),
    single: flags.has("--single") || Boolean(url || template || email),
    url,
    template,
    screenshot: values.get("--screenshot"),
    email,
    limit,
  };
}

module.exports = { parseFlowArgs };
