const fs = require("fs");
const { cfg, abs } = require("./config");

const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i;

function fromFile(src) {
  const raw = fs.readFileSync(abs(src.path), "utf8");

  if (src.path.endsWith(".json")) {
    return JSON.parse(raw).map((u) => (typeof u === "string" ? { email: u } : u));
  }

  // CSV or plain text – one email per line (header ok)
  return raw
    .split(/\r?\n/)
    .map((line) => line.match(EMAIL_RE)?.[0])
    .filter(Boolean)
    .map((email) => ({ email }));
}

function loadUsers() {
  const src = cfg.emailSource;
  if (src.type !== "file") {
    throw new Error('emailSource.type must be "file" in this version.');
  }
  return fromFile(src);
}

module.exports = { loadUsers };

if (require.main === module) {
  const users = loadUsers();
  console.log(`${users.length} email(s):`);
  users.forEach((u) => console.log(" -", u.email));
}
