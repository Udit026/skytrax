const { spawn } = require("child_process");
const path = require("path");
const root = path.resolve(__dirname, "..");

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { cwd: root, stdio: "inherit", shell: true });
    child.on("exit", (code) => (code === 0 ? resolve() : reject(new Error(`exit ${code}`))));
  });
}

(async () => {
  const server = spawn("node", ["mock/server.js"], { cwd: root, stdio: "inherit" });
  await new Promise((r) => setTimeout(r, 800));
  try {
    // Temporarily point config at mock for the test
    const fs = require("fs");
    const cfgPath = path.join(root, "flow.config.json");
    const original = fs.readFileSync(cfgPath, "utf8");
    const testCfg = JSON.parse(original);
    testCfg.form.url = "http://127.0.0.1:3456/";
    testCfg.form.emailSelector = "input[name=email]";
    testCfg.form.fields = {
      bestAirport: { selector: "input[name=bestAirport]", type: "text" },
      whyBest: { selector: "textarea[name=whyBest]", type: "text" },
      usage: { selector: "input[name=usage]", type: "radio" },
      lastUsed: { selector: "select[name=lastUsed]", type: "select" },
      country: { selector: "input[name=country]", type: "text" },
      terms: { selector: "input[name=terms]", type: "checkbox" },
    };
    testCfg.form.submitSelector = "button[type=submit]";
    testCfg.dashboard.enabled = false;
    fs.writeFileSync(cfgPath, JSON.stringify(testCfg, null, 2));

    console.log("\nRunning dry-run...");
    await run("node", ["src/flow.js", "--dry", "--limit", "1"]);
    console.log("\nMock test OK");

    fs.writeFileSync(cfgPath, original); // restore
  } finally {
    server.kill();
  }
})().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
