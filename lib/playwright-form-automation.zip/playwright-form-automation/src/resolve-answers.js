/**
 * Turns a flexible answers.template.json into concrete values for one submission.
 *
 * Supported answer_type values:
 *   fixed     → use "answer" as-is
 *   random    → pick from answer_pool.answers (or options)
 *   dropdown  → pick from options (random or fixed)
 *   radio     → same as dropdown
 *   dynamic   → for email (filled by the flow itself)
 *
 * Also supports a top-level "ratings" shortcut that applies one value
 * (or a map) to many rating question ids.
 */
const fs = require("fs");
const path = require("path");
const { cfg, abs } = require("./config");

// Track previously used random answers so unique_per_submission works across a run
const usedRandom = new Map(); // key → Set of already-used values

function pickRandom(list, uniqueKey) {
  if (!list || list.length === 0) return null;
  let pool = list;
  if (uniqueKey) {
    if (!usedRandom.has(uniqueKey)) usedRandom.set(uniqueKey, new Set());
    const used = usedRandom.get(uniqueKey);
    const available = list.filter((v) => !used.has(v));
    pool = available.length ? available : list; // reset if exhausted
  }
  const value = pool[Math.floor(Math.random() * pool.length)];
  if (uniqueKey) usedRandom.get(uniqueKey).add(value);
  return value;
}

function resolveQuestion(q) {
  const type = (q.answer_type || q.type || "fixed").toLowerCase();

  if (type === "fixed") {
    return q.answer ?? q.value ?? null;
  }

  if (type === "random" || type === "dropdown" || type === "radio") {
    // Prefer explicit answer if present
    if (q.answer !== undefined && q.answer !== null) return q.answer;

    const pool =
      q.answer_pool?.answers ||
      q.options?.map((o) => (typeof o === "string" ? o : o.value || o.label)) ||
      [];

    const unique =
      q.selection?.unique_per_submission === true
        ? `q${q.question_id || q.question || Math.random()}`
        : null;

    return pickRandom(pool, unique);
  }

  if (type === "dynamic") {
    // handled by flow (e.g. email)
    return null;
  }

  // Fallback
  return q.answer ?? null;
}

/**
 * Resolve a full template into a flat key→value object the filler can use.
 *
 * Mapping strategy:
 *  1. If the question has a "fieldKey" → use that as the key
 *  2. Else if question_id is present → use "q{id}"
 *  3. Else use a slug of the question text
 */
function resolveTemplate(template) {
  const result = {};

  // Support both { questions: [...] } and a flat object of field keys
  const questions = Array.isArray(template.questions)
    ? template.questions
    : Array.isArray(template)
    ? template
    : null;

  if (questions) {
    for (const item of questions) {
      // Nested section with its own questions array (e.g. ratings block)
      if (item.section_instruction && Array.isArray(item.questions)) {
        for (const q of item.questions) {
          const key = q.fieldKey || (q.question_id != null ? `q${q.question_id}` : null);
          if (!key) continue;
          result[key] = resolveQuestion(q);
        }
        continue;
      }

      // Skip pure instruction / terms / submission blocks that have no answer
      if (item.submission_step || (item.terms_url && !item.answer && !item.answer_type)) {
        // terms confirmation
        if (item.checked || item.answer) {
          result.terms = item.answer || true;
        }
        continue;
      }

      const key =
        item.fieldKey ||
        (item.question_id != null ? `q${item.question_id}` : null) ||
        (item.question ? item.question.slice(0, 40).replace(/\W+/g, "_") : null);

      if (!key) continue;

      // Dynamic email is filled by the flow
      if (item.answer_type === "dynamic" && (item.input_type === "email" || key === "email")) {
        continue;
      }

      result[key] = resolveQuestion(item);
    }
  } else {
    // Flat map style: { "bestAirport": "Delhi Airport", "whyBest": { "answer_type": "random", ... } }
    for (const [key, val] of Object.entries(template)) {
      if (key.startsWith("_") || key === "COMMENT") continue;
      if (val && typeof val === "object" && (val.answer_type || val.type)) {
        result[key] = resolveQuestion(val);
      } else {
        result[key] = val;
      }
    }
  }

  // Optional global ratings shortcut
  if (template.ratings) {
    const r = template.ratings;
    if (typeof r === "string" || typeof r === "number") {
      result._ratingDefault = String(r);
    } else if (typeof r === "object") {
      Object.assign(result, r);
    }
  }

  return result;
}

function loadAndResolve(overridePath) {
  const templatePath = abs(overridePath || cfg.templatePath || "data/answers.template.json");
  if (!fs.existsSync(templatePath)) {
    throw new Error(`Template not found: ${templatePath}`);
  }
  const template = JSON.parse(fs.readFileSync(templatePath, "utf8"));
  return resolveTemplate(template);
}

module.exports = { resolveTemplate, loadAndResolve, pickRandom };

// CLI: print one resolved set of answers
if (require.main === module) {
  try {
    const resolved = loadAndResolve();
    console.log(JSON.stringify(resolved, null, 2));
  } catch (e) {
    console.error(e.message);
    process.exit(1);
  }
}
