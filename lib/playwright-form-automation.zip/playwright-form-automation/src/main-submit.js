const MAIN_POST_PATH = "/Surveys/Airport/admin.php";

// Real confirmation heading: "Thank you ... Gracias ... ..." (verified from saved evidence).
const CONFIRMATION_RE = /\bthank\s+you\b.{0,12}\bgracias\b/is;
const sameSite = (a, b) => a.protocol === b.protocol && a.hostname.replace(/^www\./, "") === b.hostname.replace(/^www\./, "");

// Polls from Node over page.frames() on every tick, so a replaced/navigated frame or a top-level
// navigation never leaves a stale reference. Armed before the Submit click; bounded by timeoutMs.
function makeSuccessObserver(page, origin, timeoutMs) {
  const expected = new URL(origin);
  const control = { stopped: false };
  const diag = { frames: [], lastError: null };
  const promise = (async () => {
    const deadline = Date.now() + timeoutMs;
    while (!control.stopped && Date.now() < deadline) {
      diag.frames = [];
      for (const frame of page.frames()) {
        let url;
        try { url = new URL(frame.url()); } catch { continue; }
        if (!sameSite(url, expected)) continue;
        try {
          const text = await frame.evaluate(() => document.body?.innerText || "");
          const matched = CONFIRMATION_RE.test(text);
          diag.frames.push({ path: url.pathname, main: frame === page.mainFrame(), matched });
          if (matched) return { confirmed: true, method: "visible_thank_you_heading", frame: `${url.origin}${url.pathname}`, mainFrame: frame === page.mainFrame() };
        } catch (error) {
          diag.lastError = String(error?.message || error).slice(0, 200);
        }
      }
      await new Promise((resolve) => setTimeout(resolve, 250));
    }
    return { confirmed: false };
  })();
  return { promise, diag, stop: () => { control.stopped = true; } };
}

async function hasVisibleSurveyRejection(page, origin, pathPrefix) {
  try {
    return await page.evaluate(({ expectedOrigin, expectedPathPrefix }) => {
      const selectors = ".has-error, .error, label.error, .help-block, .text-danger";
      const docs = [document];
      for (const frame of document.querySelectorAll("iframe")) {
        try { if (frame.contentDocument) docs.push(frame.contentDocument); } catch {}
      }
      return docs.some((doc) => {
        try {
          if (doc.location.origin !== expectedOrigin || !doc.location.pathname.startsWith(expectedPathPrefix)) return false;
          return Array.from(doc.querySelectorAll(selectors)).some((element) =>
            element.getClientRects().length > 0 && Boolean(element.textContent.trim())
          );
        } catch {
          return false;
        }
      });
    }, { expectedOrigin: origin, expectedPathPrefix: pathPrefix });
  } catch {
    return false;
  }
}

function isIntendedSurveyResponse(response, formFrame, expectedOrigin) {
  const request = response.request();
  if (request.method() !== "POST") return false;
  try {
    const responseUrl = new URL(response.url());
    return request.frame() === formFrame &&
      responseUrl.origin === expectedOrigin &&
      responseUrl.pathname === MAIN_POST_PATH;
  } catch {
    return false;
  }
}

async function submitMainOnce({ page, formFrame, submitSelector, formUrl, timeoutMs = 30000 }) {
  let configuredUrl;
  try { configuredUrl = new URL(formUrl); }
  catch { return { status: "uncertain", response: null, reason: "invalid_configured_form_url" }; }

  const pathPrefix = configuredUrl.pathname.slice(0, configuredUrl.pathname.lastIndexOf("/") + 1);
  const responsePromise = new Promise((resolve) => {
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(responseTimer);
      page.off("response", onResponse);
      resolve(result);
    };
    const onResponse = (response) => {
      if (isIntendedSurveyResponse(response, formFrame, configuredUrl.origin)) finish({ response });
    };
    const responseTimer = setTimeout(() => finish({ error: new Error("matching_response_timeout") }), timeoutMs);
    page.on("response", onResponse);
  });
  const observer = makeSuccessObserver(page, configuredUrl.origin, timeoutMs);

  let clickFailed = false;
  try {
    await formFrame.locator(submitSelector).click({ noWaitAfter: true });
  } catch {
    clickFailed = true;
  }

  const observed = await responsePromise;
  if (!observed.response) {
    observer.stop();
    return {
      status: "uncertain",
      response: null,
      reason: observed.error?.message || (clickFailed ? "click_or_response_unobserved" : "matching_response_unobserved"),
    };
  }

  const response = observed.response;
  const statusCode = response.status();
  if (statusCode === 403) { observer.stop(); return { status: "forbidden", response, reason: "http_403" }; }
  if (statusCode >= 400 && statusCode < 500) { observer.stop(); return { status: "rejected", response, reason: "http_4xx" }; }

  const found = await observer.promise;
  const hasSuccess = found.confirmed;
  if (response.ok() && hasSuccess) {
    console.log(`  Confirmation: ${found.method} | ${found.mainFrame ? "main page" : "iframe"} ${found.frame}`);
    return { status: "confirmed", response, reason: "thank_you_content" };
  }
  console.log(`  Confirmation not observed; same-site frames: ${JSON.stringify(observer.diag.frames)}${observer.diag.lastError ? ` | last error: ${observer.diag.lastError}` : ""}`);
  if (await hasVisibleSurveyRejection(page, configuredUrl.origin, pathPrefix)) {
    return { status: "rejected", response, reason: "visible_form_rejection" };
  }
  return { status: "uncertain", response, reason: hasSuccess ? "non_success_http_status" : "thank_you_not_observed" };
}

module.exports = { submitMainOnce, MAIN_POST_PATH };
