const test = require("node:test");
const assert = require("node:assert/strict");
const { chromium } = require("playwright");
const { parseFlowArgs } = require("../src/flow-args");
const { submitMainOnce } = require("../src/main-submit");
const { runConfirmedCycle, runSelectedEmails, selectEmailCandidates } = require("../src/submission-lifecycle");

const baseUrl = "https://fixture.test/Surveys/Airport/best_airport.html";

async function createFixture(mode) {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  const posts = [];
  const pageErrors = [];
  const consoleMessages = [];
  page.on("pageerror", (error) => pageErrors.push(error.message));
  page.on("console", (message) => consoleMessages.push(message.text()));
  await page.route("**/*", async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    if (url.origin !== "https://fixture.test") return route.abort();

    if (request.method() === "POST" && url.pathname === "/Surveys/Airport/admin.php") {
      const body = request.postData() || "";
      let requestMode = "";
      try { requestMode = new URL(request.frame().url()).searchParams.get("mode") || ""; } catch {}
      posts.push({ body, frameUrl: request.frame().url() });
      if (body === "noise") return route.fulfill({ status: 200, body: "unrelated response" });
      if (requestMode === "forbidden") return route.fulfill({ status: 403, body: "Forbidden" });
      if (requestMode === "unconfirmed") return route.fulfill({ status: 200, body: "Still processing" });
      if (requestMode === "replace") return route.fulfill({ status: 200, body: "Accepted" });
      return route.fulfill({ status: 200, body: "<h1>Thank you ... Gracias ... Terima kasih</h1>" });
    }

    if (url.pathname === "/Surveys/Airport/best_airport.html") {
      return route.fulfill({ status: 200, contentType: "text/html", body: '<!doctype html><iframe id="survey" src="/Surveys/Airport/form.html?mode=' + mode + '"></iframe>' });
    }
    if (url.pathname === "/Surveys/Airport/form.html") {
      const html = `<!doctype html><html><body>
        <form><input type="email" name="email"/><button type="submit">Submit</button></form>
        <script>
          window.__submitRuns = 0;
          document.querySelector('form').addEventListener('submit', async (event) => {
            event.preventDefault();
            window.__submitRuns += 1;
            const mode = new URL(location.href).searchParams.get('mode');
            if (mode === 'matching') void parent.fetch('/Surveys/Airport/admin.php', { method: 'POST', body: 'noise' });
            const response = await fetch('/Surveys/Airport/admin.php', { method: 'POST', body: 'survey' });
            const body = await response.text();
            if (mode === 'matching') await new Promise((resolve) => setTimeout(resolve, 60));
            if (mode === 'replace') {
              const replacement = parent.document.createElement('iframe');
              replacement.id = 'survey';
              replacement.src = '/Surveys/Airport/thankyou.html';
              parent.document.getElementById('survey').replaceWith(replacement);
            } else {
              document.body.innerHTML = body;
            }
          });
        </script>
      </body></html>`;
      return route.fulfill({ status: 200, contentType: "text/html", body: html });
    }
    if (url.pathname === "/Surveys/Airport/thankyou.html") {
      return route.fulfill({ status: 200, contentType: "text/html", body: "<!doctype html><h1>Thank you ... Gracias ... Terima kasih</h1>" });
    }
    return route.fulfill({ status: 404, body: "Not found" });
  });

  await page.goto(baseUrl);
  const formFrame = page.frames().find((frame) => frame.url().includes("/Surveys/Airport/form.html"));
  assert.ok(formFrame, "fixture survey frame should load");
  await formFrame.locator('input[type="email"]').fill("fixture@example.test");
  return { browser, page, formFrame, posts, pageErrors, consoleMessages };
}

test("CLI keeps --single as mode and parses both limit forms before browser launch", () => {
  assert.deepEqual(parseFlowArgs(["--single", "--limit", "1"]).limit, 1);
  assert.equal(parseFlowArgs(["--single", "--limit=1"]).single, true);
  assert.equal(parseFlowArgs(["--single", "--limit=1"]).limit, 1);
  assert.throws(() => parseFlowArgs(["--single", "1"]), /Unexpected positional argument/);
  assert.throws(() => parseFlowArgs(["--single", "--limit=0"]), /positive whole number/);
});

test("200 plus delayed Thank-you content confirms only the intended survey-frame POST", async (t) => {
  const fixture = await createFixture("matching");
  t.after(() => fixture.browser.close());
  const result = await submitMainOnce({ page: fixture.page, formFrame: fixture.formFrame, submitSelector: "button[type=submit]", formUrl: baseUrl, timeoutMs: 5000 });
  const submitRuns = await fixture.formFrame.evaluate(() => window.__submitRuns);
  assert.equal(result.status, "confirmed", `${result.reason}; posts=${JSON.stringify(fixture.posts)}; submit runs=${submitRuns}; page errors=${fixture.pageErrors.join(" | ")}; console=${fixture.consoleMessages.join(" | ")}`);
  assert.equal(fixture.posts.length, 2);
  assert.ok(fixture.posts.some((post) => post.body === "noise"));
  assert.ok(fixture.posts.some((post) => post.body === "survey"));
});

test("HTTP 200 without Thank-you stays uncertain", async (t) => {
  const fixture = await createFixture("unconfirmed");
  t.after(() => fixture.browser.close());
  const result = await submitMainOnce({ page: fixture.page, formFrame: fixture.formFrame, submitSelector: "button[type=submit]", formUrl: baseUrl, timeoutMs: 1200 });
  assert.equal(result.status, "uncertain");
  assert.equal(fixture.posts.filter((post) => post.body === "survey").length, 1);
});

test("HTTP 403 is classified as forbidden without a second submit", async (t) => {
  const fixture = await createFixture("forbidden");
  t.after(() => fixture.browser.close());
  const result = await submitMainOnce({ page: fixture.page, formFrame: fixture.formFrame, submitSelector: "button[type=submit]", formUrl: baseUrl, timeoutMs: 1200 });
  assert.equal(result.status, "forbidden");
  assert.equal(fixture.posts.filter((post) => post.body === "survey").length, 1);
});

test("Thank-you in a replacement frame confirms the original frame's POST", async (t) => {
  const fixture = await createFixture("replace");
  t.after(() => fixture.browser.close());
  const result = await submitMainOnce({ page: fixture.page, formFrame: fixture.formFrame, submitSelector: "button[type=submit]", formUrl: baseUrl, timeoutMs: 1200 });
  assert.equal(result.status, "confirmed");
  assert.equal(fixture.posts.filter((post) => post.body === "survey").length, 1);
});

test("confirmation precedes the 30-second wait, dashboard confirmation, and processed marking", async () => {
  const events = [];
  const result = await runConfirmedCycle({
    submitMain: async () => { events.push("main-confirmed"); return { status: "confirmed" }; },
    waitAfterSubmit: async () => { events.push("30-second-gap"); },
    saveDashboard: async () => { events.push("save-click"); events.push("Upload another"); },
    markProcessed: async () => { events.push("processed"); },
  });
  assert.equal(result.status, "completed");
  assert.deepEqual(events, ["main-confirmed", "30-second-gap", "save-click", "Upload another", "processed"]);
});

test("uncertain result stops before dashboard or processed marking", async () => {
  const events = [];
  const result = await runConfirmedCycle({
    submitMain: async () => { events.push("main-uncertain"); return { status: "uncertain" }; },
    waitAfterSubmit: async () => { events.push("wait"); },
    saveDashboard: async () => { events.push("dashboard"); },
    markProcessed: async () => { events.push("processed"); },
  });
  assert.equal(result.status, "uncertain");
  assert.deepEqual(events, ["main-uncertain"]);
});

test("dashboard failure does not invoke the main POST callback again", async () => {
  let checkpointStage = "main";
  let mainPosts = 0;
  const submitMain = async () => {
    if (["main_submit_started", "dashboard_saved"].includes(checkpointStage)) return { status: "confirmed" };
    mainPosts += 1;
    checkpointStage = "main_submit_started";
    return { status: "confirmed" };
  };
  await assert.rejects(runConfirmedCycle({
    submitMain,
    waitAfterSubmit: async () => {},
    saveDashboard: async () => { throw new Error("fixture dashboard failure"); },
    markProcessed: async () => assert.fail("failed dashboard must not mark processed"),
  }), /fixture dashboard failure/);
  const resumed = await runConfirmedCycle({
    submitMain,
    waitAfterSubmit: async () => {},
    saveDashboard: async () => { checkpointStage = "dashboard_saved"; },
    markProcessed: async () => {},
  });
  assert.equal(resumed.status, "completed");
  assert.equal(mainPosts, 1);
});

test("limit one selects and attempts no more than one distinct email after failure", async () => {
  const args = parseFlowArgs(["--single", "--limit=1"]);
  const selected = selectEmailCandidates([
    { email: "one@example.test" },
    { email: "two@example.test" },
  ], { alreadyUsed: new Set(), unconfirmed: [], limit: args.limit });
  assert.equal(selected.length, 1);
  const attempted = [];
  await assert.rejects(runSelectedEmails(selected, async (user) => {
    attempted.push(user.email);
    throw new Error("fixture failure");
  }), /fixture failure/);
  assert.deepEqual(attempted, ["one@example.test"]);
});

test("403 result prevents attempting the next selected email", async () => {
  const selected = [{ email: "one@example.test" }, { email: "two@example.test" }];
  const attempted = [];
  await assert.rejects(runSelectedEmails(selected, async (user) => {
    attempted.push(user.email);
    const result = await runConfirmedCycle({
      submitMain: async () => ({ status: "forbidden" }),
      waitAfterSubmit: async () => {},
      saveDashboard: async () => assert.fail("403 must not reach dashboard"),
      markProcessed: async () => assert.fail("403 must not mark processed"),
    });
    if (result.status !== "completed") throw new Error("halt batch on 403");
  }), /halt batch on 403/);
  assert.deepEqual(attempted, ["one@example.test"]);
});
