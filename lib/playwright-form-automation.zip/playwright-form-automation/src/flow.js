/**
 * Flexible form automation flow
 *
 * One-form mode: fetch next CSV email → fill → screenshot email/submit area → submit.
 * Batch mode: process pending CSV emails → fill → screenshot → submit → upload proof.
 *
 * Usage:
 *   npm run fill
 *   npm run dry
 *   npm run run -- --limit 1
 *   npm run run
 */
const fs = require("fs");
const path = require("path");
const { cfg, abs, env } = require("./config");
const { openBrowser } = require("./browser");
const { loadUsers } = require("./emails");
const { loadAndResolve } = require("./resolve-answers");
const { parseFlowArgs } = require("./flow-args");
const { submitMainOnce } = require("./main-submit");
const { runConfirmedCycle, runSelectedEmails, selectEmailCandidates } = require("./submission-lifecycle");

let cli;
try {
  cli = parseFlowArgs(process.argv.slice(2));
} catch (error) {
  console.error(error.message);
  process.exit(2);
}
const dry = cli.dry;
const formUrl = cli.url || env.FORM_URL || cfg.form.url;
const templateOverride = cli.template || env.TEMPLATE_PATH;
const screenshotOverride = cli.screenshot;
const emailOverride = cli.email;
const singleForm = cli.single;
const limit = cli.limit;

const stateFile = abs("data/processed.json");
const usedEmailsFile = abs("data/used-emails.json");
const progressFile = abs("data/flow-progress.json");
const unconfirmedFile = abs("data/unconfirmed-emails.json");
let dashboardLoginDone = false;
const slug = (e) => e.replace(/[^a-z0-9]/gi, "_");

const loadState = () => {
  try {
    return new Set(JSON.parse(fs.readFileSync(stateFile, "utf8")));
  } catch {
    return new Set();
  }
};
const saveState = (s) => fs.writeFileSync(stateFile, JSON.stringify([...s], null, 2));
const loadUsedEmails = () => {
  try {
    return new Set(JSON.parse(fs.readFileSync(usedEmailsFile, "utf8")).map((email) => String(email).toLowerCase()));
  } catch {
    return new Set();
  }
};
const saveUsedEmails = (s) => fs.writeFileSync(usedEmailsFile, JSON.stringify([...s], null, 2));
const loadUnconfirmedEmails = () => {
  try {
    const entries = JSON.parse(fs.readFileSync(unconfirmedFile, "utf8"));
    return Array.isArray(entries) ? entries.map((entry) => String(entry.email || "").toLowerCase()).filter(Boolean) : [];
  } catch {
    return [];
  }
};
const loadProgress = () => {
  try {
    return { completedCycles: 0, currentEmail: null, stage: "next", screenshotPath: null, waitUntil: null,
      ...JSON.parse(fs.readFileSync(progressFile, "utf8")) };
  } catch {
    return { completedCycles: 0, currentEmail: null, stage: "next", screenshotPath: null, waitUntil: null };
  }
};
const saveProgress = (progress) => fs.writeFileSync(progressFile, JSON.stringify(progress, null, 2));
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function retryForever(label, operation) {
  let attempt = 0;
  for (;;) {
    attempt += 1;
    console.log(`${label}: attempt ${attempt}`);
    const heartbeat = setInterval(() => console.log(`${label}: still waiting...`), 10000);
    try {
      const result = await operation();
      clearInterval(heartbeat);
      return result;
    } catch (error) {
      clearInterval(heartbeat);
      if (error.noRetry) throw error;
      console.error(`${label} failed; retrying in 5 seconds: ${error.message}`);
      await sleep(5000);
    }
  }
}
async function waitUntil(timestamp) {
  if (!timestamp) return;
  const remaining = timestamp - Date.now();
  if (remaining > 0) await sleep(remaining);
}
const uniqueEmails = (users) => {
  const seen = new Set();
  return users.filter((user) => {
    const email = user.email.toLowerCase();
    if (seen.has(email)) return false;
    seen.add(email);
    return true;
  });
};

function collectAnswerValues(value, values = new Set()) {
  if (typeof value === "string" || typeof value === "number") {
    const text = String(value);
    if (text) values.add(text);
  } else if (Array.isArray(value)) {
    value.forEach((item) => collectAnswerValues(item, values));
  } else if (value && typeof value === "object") {
    Object.values(value).forEach((item) => collectAnswerValues(item, values));
  }
  return values;
}

function sanitizeResponseExcerpt(text, email, answers) {
  let excerpt = text;
  const sensitiveValues = collectAnswerValues(answers);
  sensitiveValues.add(email);
  for (const value of [...sensitiveValues].sort((a, b) => b.length - a.length)) {
    const variants = [value, encodeURIComponent(value), value
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;").replace(/'/g, "&#39;")];
    for (const variant of variants) {
      if (!variant) continue;
      const escaped = variant.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      excerpt = excerpt.replace(new RegExp(escaped, "gi"), "[REDACTED]");
    }
  }
  excerpt = excerpt
    .replace(/(<input\b[^>]*\bvalue\s*=\s*)([\"'])[^\"']*\2/gi, "$1$2[REDACTED]$2")
    .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, "[REDACTED_EMAIL]")
    .replace(/\bBearer\s+[A-Za-z0-9._~+/-]+=*/gi, "Bearer [REDACTED]")
    .replace(/((?:csrf|xsrf|token|secret|password|authorization|cookie|session)[\w-]*\s*[\"']?\s*[:=]\s*[\"']?)[^&\s\"'<>]+/gi, "$1[REDACTED]")
    .replace(/https?:\/\/[^\s\"'<>]+/gi, (rawUrl) => {
      try {
        const parsed = new URL(rawUrl);
        return `${parsed.origin}${parsed.pathname}`;
      } catch {
        return "[URL]";
      }
    });
  return excerpt.slice(0, 1200);
}

async function getSanitizedResponseExcerpt(response, email, answers) {
  const contentType = response.headers()["content-type"] || "";
  if (!/^(text\/|application\/(?:json|problem\+json|xhtml\+xml))/i.test(contentType)) {
    return "[non-text response omitted]";
  }
  try {
    const body = await response.body();
    return sanitizeResponseExcerpt(body.subarray(0, 8192).toString("utf8"), email, answers);
  } catch {
    return "[response body unavailable]";
  }
}

function getSanitizedResponseHeaders(response) {
  const headers = response.headers();
  const safeNames = ["content-type", "date", "server", "retry-after", "via", "cf-ray", "x-request-id", "x-correlation-id"];
  return Object.fromEntries(safeNames
    .filter((name) => headers[name])
    .map((name) => [name, String(headers[name]).replace(/[\r\n\t]/g, " ").slice(0, 200)]));
}

function formatDiagnosticUrl(rawUrl) {
  if (typeof rawUrl !== "string" || !rawUrl.trim()) return "[blank frame]";
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return "[unavailable frame URL]";
  }
  if (parsed.protocol === "about:" && parsed.pathname === "blank") return "about:blank";
  if (parsed.protocol === "http:" || parsed.protocol === "https:") {
    return `${parsed.origin}${parsed.pathname}`;
  }
  return `[non-http ${parsed.protocol.slice(0, -1)} URL]`;
}

function appendJsonRecord(filePath, record) {
  let records = [];
  try {
    records = JSON.parse(fs.readFileSync(filePath, "utf8"));
    if (!Array.isArray(records)) records = [];
  } catch {}
  records.push(record);
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(records, null, 2));
}

function saveUnconfirmedEmail(email, stage, screenshotPath, reason, status) {
  const filePath = abs("data/unconfirmed-emails.json");
  let records = [];
  try {
    records = JSON.parse(fs.readFileSync(filePath, "utf8"));
    if (!Array.isArray(records)) records = [];
  } catch {}
  const existingIndex = records.findIndex((entry) => String(entry.email).toLowerCase() === email.toLowerCase());
  const entry = { email, stage, screenshotPath, reason, status, at: new Date().toISOString() };
  if (existingIndex >= 0) records[existingIndex] = { ...records[existingIndex], ...entry };
  else records.push(entry);
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(records, null, 2));
}

async function persistMainFailure(page, email, progress, answers, outcome) {
  const occurredAt = new Date().toISOString();
  const screenshotPath = abs(`screenshots/main-survey-${outcome.status}-${Date.now()}.png`);
  const diagnosticPath = abs("data/main-survey-failures.json");
  const response = outcome.response || null;
  const status = response ? response.status() : null;
  const reason = `Main survey ${outcome.status}; submission not confirmed.`;

  if (status === 403) progress.mainSurveyHttpStatus = 403;
  progress.failureScreenshotPath = null;
  progress.diagnosticPath = "data/main-survey-failures.json";
  try { saveProgress(progress); } catch {}

  const screenshotSaved = await page.screenshot({ path: screenshotPath, fullPage: true }).then(() => true).catch(() => false);
  const savedScreenshotPath = screenshotSaved ? path.relative(process.cwd(), screenshotPath) : null;
  progress.failureScreenshotPath = savedScreenshotPath;
  try { saveProgress(progress); } catch {}

  try { saveUnconfirmedEmail(email, progress.stage, savedScreenshotPath, reason, status); } catch {}
  try {
    appendJsonRecord(diagnosticPath, {
      at: occurredAt,
      outcome: outcome.status,
      reason: outcome.reason,
      method: response ? response.request().method() : null,
      endpoint: response ? formatDiagnosticUrl(response.url()) : "[response unavailable]",
      status,
      headers: response ? getSanitizedResponseHeaders(response) : {},
      bodyExcerpt: response ? await getSanitizedResponseExcerpt(response, email, answers) : "[response unavailable]",
      screenshotPath: savedScreenshotPath,
    });
  } catch {}
}

function loadDashboardConfig() {
  const base = cfg.dashboard || {};
  const templatePath = base.templatePath || "data/dashboard.template.json";
  const template = JSON.parse(fs.readFileSync(abs(templatePath), "utf8"));
  const fields = { ...(base.fields || {}) };
  let emailSelector = base.emailSelector;
  let fileSelector = base.fileSelector;
  for (const [key, def] of Object.entries(template.fields || {})) {
    if (!def || typeof def !== "object" || !def.selector) continue;
    if (key === "email") emailSelector = def.selector;
    else if (key === "screenshots") fileSelector = def.selector;
    else fields[key] = {
      ...def,
      type: def.type || "text",
    };
  }
  return {
    ...base,
    uploadUrl: template.url || base.uploadUrl,
    templatePath,
    login: template.login || base.login,
    emailSelector,
    fileSelector,
    submitSelector: template.submit?.selector || base.submitSelector,
    fields,
  };
}

function validateDashboardConfig() {
  const d = loadDashboardConfig();
  if (!d?.enabled) throw new Error("Set dashboard.enabled to true in flow.config.json.");
  if (!d.uploadUrl || String(d.uploadUrl).includes("PASTE_")) {
    throw new Error("Set dashboard.uploadUrl in flow.config.json before processing emails.");
  }
  if (!d.emailSelector || !d.fileSelector || !d.submitSelector || String(d.submitSelector).includes("PASTE_")) {
    throw new Error("Set dashboard emailSelector, fileSelector, and submitSelector in flow.config.json.");
  }
  if (!d.login?.url || String(d.login.url).includes("PASTE_")) {
    throw new Error("Set dashboard.login.url in flow.config.json; the dashboard requires login.");
  }
  if (!d.login.userSelector || !d.login.passSelector || !d.login.submit) {
    throw new Error("Set dashboard.login userSelector, passSelector, and submit in flow.config.json.");
  }
  if (!env.DASH_USER || !env.DASH_PASS) {
    throw new Error("Set DASH_USER and DASH_PASS in .env for the dashboard login.");
  }
  const templatePath = abs(d.templatePath);
  if (!fs.existsSync(templatePath)) throw new Error(`Dashboard template not found: ${templatePath}`);
}

async function checkControl(input) {
  input = input.first();
  await input.scrollIntoViewIfNeeded();
  if (await input.isChecked()) return;
  const id = await input.getAttribute("id");
  const label = id ? input.locator(`xpath=ancestor::html//label[@for="${cssValue(id)}"]`).first() : input.locator("xpath=..");
  try { await label.click({ timeout: 5000 }); } catch {}
  if (await input.isChecked()) return;
  await input.check({ force: true });
  if (!(await input.isChecked())) throw new Error(`Could not check control${id ? ` #${id}` : ""}.`);
}

async function fillField(page, def, value) {
  if (value === undefined || value === null) return;
  const loc = page.locator(def.selector).first();

  switch (def.type) {
    case "text":
    case "email":
    case "password":
      await loc.fill(String(value));
      break;
    case "select":
      await loc.selectOption(String(value));
      break;
    case "radio":
      await checkControl(page.locator(`${def.selector}[value="${value}"]`));
      break;
    case "checkbox":
      if (value === true || value === "true" || value === "yes" || value === "1") {
        await checkControl(loc);
      } else {
        await loc.uncheck().catch(() => {});
      }
      break;
    default:
      throw new Error(`Unknown field type: ${def.type}`);
  }
}

async function login(page, def, userEnv, passEnv) {
  if (!def || !def.url || String(def.url).includes("PASTE_")) return;
  const user = env[userEnv] || "";
  const pass = env[passEnv] || "";
  if (!user || !pass) {
    console.warn(`Login skipped – set ${userEnv} and ${passEnv} in .env`);
    return;
  }
  console.log("  Opening dashboard login page...");
  await page.goto(def.url, { waitUntil: "domcontentloaded" });
  console.log("  Entering dashboard credentials...");
  await page.fill(def.userSelector, user);
  await page.fill(def.passSelector, pass);
  console.log("  Submitting dashboard login...");
  await page.locator(def.submit).first().click();
  await page.waitForURL((url) => !url.pathname.replace(/\/$/, "").endsWith("/login"), { timeout: 60000 });
  console.log("  Dashboard login succeeded.");
}

async function takeShot(page, filePath) {
  const shotCfg = cfg.form.screenshot || { mode: "fullPage" };
  if (shotCfg.mode === "element" && shotCfg.elementSelector) {
    const el = page.locator(shotCfg.elementSelector).first();
    await el.screenshot({ path: filePath });
  } else {
    await page.screenshot({ path: filePath, fullPage: true });
  }
}

async function takeEmailSubmitShot(page, emailSelector, submitSelector, filePath, scope = page) {
  const email = scope.locator(emailSelector).first();
  const submit = scope.locator(submitSelector).first();
  const terms = email.locator("xpath=ancestor::*[contains(@class,'form-group')][1]/preceding-sibling::*[1]");
  const form = email.locator("xpath=ancestor::form[1]");
  const above = terms.locator("xpath=preceding-sibling::*[1]"); // field just above the terms block (country)
  // Generous padding so the terms text, checkbox row, email row and Submit are never clipped.
  const padding = 32;
  const original = page.viewportSize();
  try {
    // Desktop-width framing (matches the live form layout); viewport is restored in finally.
    await email.waitFor({ state: "visible" });
    await submit.waitFor({ state: "visible" });
    // The terms confirmation must be marked in the proof; checkControl is a no-op if already checked.
    const termsInput = terms.locator("input[type=radio], input[type=checkbox]").first();
    if (await termsInput.count()) await checkControl(termsInput);
    let clip;
    for (let pass = 0; pass < 3; pass++) {
      const scrollTarget = (await above.count().catch(() => 0)) ? above : terms;
      await scrollTarget.evaluate((el) => el.scrollIntoView({ block: "start" })).catch(() => {});
      await page.evaluate((offset) => window.scrollBy(0, -offset), padding);
      const [emailBox, submitBox, termsBox, formBox, aboveBox] = await Promise.all([
        email.boundingBox(), submit.boundingBox(), terms.boundingBox().catch(() => null), form.boundingBox().catch(() => null),
        above.boundingBox().catch(() => null),
      ]);
      if (!emailBox || !submitBox) {
        throw new Error("Could not measure the email field and submit button for the screenshot.");
      }
      const boxes = [emailBox, submitBox, termsBox, formBox].filter(Boolean);
      const x = Math.max(0, Math.min(...boxes.map((b) => b.x)) - padding);
      const y = Math.max(0, Math.min(emailBox.y, submitBox.y, termsBox ? termsBox.y : Infinity, aboveBox ? aboveBox.y : Infinity) - padding);
      const right = Math.max(...boxes.map((b) => b.x + b.width)) + padding;
      const bottom = Math.max(emailBox.y + emailBox.height, submitBox.y + submitBox.height) + padding;
      clip = { x, y, width: right - x, height: bottom - y };
      const view = page.viewportSize();
      if (!view || bottom <= view.height) break;
      await page.setViewportSize({ width: view.width, height: Math.ceil(bottom + padding) });
      await sleep(500);
    }
    await page.screenshot({ path: filePath, clip });
  } finally {
    if (original) await page.setViewportSize(original);
  }
}

function templateQuestions(template) {
  const out = new Map();
  const visit = (items) => {
    for (const item of items || []) {
      if (!item || typeof item !== "object") continue;
      if (Array.isArray(item.questions)) {
        visit(item.questions);
        continue;
      }
      const key = item.fieldKey || (item.question_id != null ? `q${item.question_id}` : null);
      if (key) out.set(key, item.question || item.label || item.fieldKey || key);
    }
  };
  if (Array.isArray(template)) visit(template);
  else if (Array.isArray(template.questions)) visit(template.questions);
  else {
    for (const [key, value] of Object.entries(template)) {
      if (!key.startsWith("_") && value && typeof value === "object") {
        out.set(key, value.question || value.label || key);
      }
    }
  }
  return out;
}

const cssValue = (value) => String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');

async function autoFillField(page, key, question, value) {
  if (value === undefined || value === null) return false;
  const labels = [...new Set([question, key].filter(Boolean))];
  let loc;

  for (const label of labels) {
    try {
      const candidate = page.getByLabel(label, { exact: false }).first();
      if (await candidate.count()) { loc = candidate; break; }
    } catch {}
  }
  if (!loc && question) {
    try {
      const group = page.getByRole("group", { name: question, exact: false });
      if (await group.count()) {
        const radio = group.locator(`input[type="radio"][value="${cssValue(value)}"]`).first();
        if (await radio.count()) { await checkControl(radio); return true; }
      }
    } catch {}
  }
  if (!loc) {
    for (const attr of ["name", "id", "aria-label", "placeholder"]) {
      for (const candidate of labels) {
        const selector = `[${attr}="${cssValue(candidate)}"]`;
        const found = page.locator(selector).first();
        if (await found.count()) { loc = found; break; }
      }
      if (loc) break;
    }
  }
  if (!loc) return false;

  const info = await loc.evaluate((el) => ({
    tag: el.tagName.toLowerCase(), type: (el.type || "").toLowerCase(),
    name: el.name || "", value: el.value || "",
  }));
  if (info.type === "radio") {
    const radio = info.name
      ? page.locator(`input[name="${cssValue(info.name)}"][value="${cssValue(value)}"]`).first()
      : loc;
    await checkControl(radio);
  } else if (info.type === "checkbox") {
    const checked = value === true || ["true", "yes", "1"].includes(String(value).toLowerCase());
    if (checked) await checkControl(loc); else await loc.uncheck();
  } else if (info.tag === "select") {
    try { await loc.selectOption(String(value)); }
    catch { await loc.selectOption({ label: String(value) }); }
  } else {
    await loc.fill(String(value));
  }
  return true;
}

async function autoFill(page, answers, templateFile, fields = {}, ratingFields = null, formLabel = "form") {
  const templatePath = abs(templateFile);
  const template = JSON.parse(fs.readFileSync(templatePath, "utf8"));
  const questions = templateQuestions(template);
  const unmatched = [];
  for (const [key, value] of Object.entries(answers)) {
    if (key.startsWith("_")) continue;
    const mapped = fields?.[key];
    if (mapped?.selector && !String(mapped.selector).includes("PASTE_")) {
      await fillField(page, mapped, value);
      continue;
    }
    const rating = key.match(/^q(.+)$/);
    const ratingCfg = rating && ratingFields;
    if (ratingCfg?.selectorPattern && ratingCfg.ids?.map(String).includes(rating[1])) {
      const selector = ratingCfg.selectorPattern.replace("{id}", rating[1]);
      await fillField(page, { selector, type: ratingCfg.type || "radio" }, value);
      continue;
    }
    if (!(await autoFillField(page, key, questions.get(key), value))) unmatched.push(key);
  }
  const rf = ratingFields;
  if (rf?.ids?.length) {
    for (const qid of rf.ids) {
      const key = `q${qid}`;
      if (answers[key] !== undefined) continue;
      if (answers._ratingDefault !== undefined) {
        await fillField(page, { selector: rf.selectorPattern.replace("{id}", qid), type: rf.type || "radio" }, answers._ratingDefault);
      }
    }
  }
  if (unmatched.length) {
    throw new Error(`Could not find ${formLabel} controls for: ${unmatched.join(", ")}. Add explicit selector mappings in flow.config.json.`);
  }
}

async function uploadProof(page, email, shotPath, onSaved, onSaveStarted) {
  const d = loadDashboardConfig();
  const failDashboard = (message) => {
    const error = new Error(message);
    error.dashboardStage = true;
    throw error;
  };
  if (!d || !d.enabled) {
    failDashboard("Dashboard submission is disabled; enable it in flow.config.json before processing emails.");
  }
  if (!d.uploadUrl || String(d.uploadUrl).includes("PASTE_")) {
    failDashboard("Set dashboard.uploadUrl in flow.config.json before processing emails.");
  }
  if (!d.emailSelector || !d.fileSelector || !d.submitSelector || String(d.submitSelector).includes("PASTE_")) {
    failDashboard("Set dashboard emailSelector, fileSelector, and submitSelector in flow.config.json.");
  }

  let saveStarted = false;
  try {
    // ---- Preparation (safe to retry: nothing is sent to /api/submissions) ----
    if (!dashboardLoginDone) {
      await login(page, d.login, "DASH_USER", "DASH_PASS");
      dashboardLoginDone = true;
    }
    await page.goto(d.uploadUrl, { waitUntil: "domcontentloaded" });
    const form = page.locator("form", { has: page.locator(d.submitSelector) });
    if ((await form.count()) !== 1) throw new Error(`expected exactly one upload form, found ${await form.count()}`);
    await form.waitFor({ state: "visible", timeout: 30000 });
    // The upload form is a React client form (onSubmit preventDefault). Before hydration a click does a
    // native GET submit to /upload? and wipes the form. Wait until React has attached onSubmit.
    const formHandle = await form.elementHandle();
    await page.waitForFunction((el) => Object.keys(el).some((k) => k.startsWith("__reactProps$") && typeof el[k]?.onSubmit === "function"),
      formHandle, { timeout: 30000 });

    const shotSize = fs.existsSync(shotPath) ? fs.statSync(shotPath).size : 0;
    if (!shotSize) throw new Error("saved proof screenshot is missing or empty");
    await form.locator(d.emailSelector).first().fill(email);
    await form.locator(d.fileSelector).first().setInputFiles(shotPath);

    const dashboardTemplate = d.templatePath || "data/dashboard.template.json";
    const dashboardAnswers = loadAndResolve(dashboardTemplate);
    await autoFill(page, dashboardAnswers, dashboardTemplate, d.fields || {}, d.ratingFields || null, "dashboard form");

    // Verify before Save. (The app clears input.files after onChange, so check its visible file list.)
    if ((await form.locator(d.emailSelector).first().inputValue()).trim() !== email) throw new Error("dashboard email field does not equal the picked email");
    const fileRow = form.locator("li").filter({ hasText: path.basename(shotPath) });
    await fileRow.first().waitFor({ state: "visible", timeout: 10000 });
    if ((await fileRow.count()) !== 1) throw new Error("proof screenshot is not listed exactly once in the dashboard form");
    const saveButton = form.locator(d.submitSelector);
    if ((await saveButton.count()) !== 1 || !(await saveButton.isEnabled())) throw new Error("Save button is not unique and enabled");
    console.log("  Dashboard preparation complete (email, screenshot, Save button verified).");

    // ---- Save (single, non-repeatable) ----
    const saveResponse = page.waitForResponse(
      (r) => r.request().method() === "POST" && new URL(r.url()).pathname === "/api/submissions", { timeout: 60000 });
    const recorded = page.getByRole("button", { name: "Upload another" }).waitFor({ timeout: 60000 });
    saveResponse.catch(() => {});
    recorded.catch(() => {});
    if (onSaveStarted) onSaveStarted();
    saveStarted = true;
    console.log("  Dashboard Save started.");
    await saveButton.click({ noWaitAfter: true });

    const response = await saveResponse;
    if (response.status() !== 201) throw new Error(`save response was HTTP ${response.status()}, not 201`);
    await recorded;
    console.log("  Dashboard save confirmed: HTTP 201 + 'Submission recorded' view.");
    if (onSaved) onSaved();

    if (d.successText) {
      await page.getByText(d.successText).first().waitFor({ timeout: 0 });
    }
  } catch (error) {
    await page.screenshot({ path: abs(`screenshots/${slug(email)}_dashboard_error.png`), fullPage: true }).catch(() => {});
    error.message = `Dashboard submission failed${saveStarted ? " AFTER Save was started (outcome uncertain; not retrying)" : ""}: ${error.message}`;
    error.dashboardStage = true;
    dashboardLoginDone = false;
    if (saveStarted) { error.noRetry = true; error.stopBatch = true; }
    throw error;
  }
}

(async () => {
  // Sanity checks
  if (!formUrl || String(formUrl).includes("PASTE_")) {
    console.error("Pass --url https://your-form-url or set form.url in flow.config.json.");
    process.exit(1);
  }

  fs.mkdirSync(abs("screenshots"), { recursive: true });

  let singleTodo;
  let singleDone;
  let usedEmails;
  let progress = loadProgress();

  // Soft recovery for blocked checkpoints (403 / unconfirmed main submit).
  // Do NOT halt the whole batch — skip that email and continue from the next one.
  if (progress.mainSurveyHttpStatus === 403 || progress.stage === "main_submit_unconfirmed") {
    const blockedEmail = progress.currentEmail;
    console.warn("────────────────────────────────────────────────────────");
    console.warn("Checkpoint recovery: previous main-survey submit was unconfirmed/403.");
    if (blockedEmail) {
      console.warn(`Skipping blocked email: ${blockedEmail}`);
      try {
        const filePath = abs("data/unconfirmed-emails.json");
        let records = [];
        try {
          records = JSON.parse(fs.readFileSync(filePath, "utf8"));
          if (!Array.isArray(records)) records = [];
        } catch {}
        if (!records.some((entry) => String(entry.email || "").toLowerCase() === blockedEmail.toLowerCase())) {
          records.push({
            email: blockedEmail,
            stage: progress.stage,
            screenshotPath: progress.screenshotPath || progress.failureScreenshotPath || null,
            reason: `Recovered from checkpoint (HTTP ${progress.mainSurveyHttpStatus || "unknown"} / ${progress.stage})`,
            status: progress.mainSurveyHttpStatus || null,
            at: new Date().toISOString(),
          });
          fs.writeFileSync(filePath, JSON.stringify(records, null, 2));
        }
      } catch (e) {
        console.warn(`Could not append unconfirmed record: ${e.message}`);
      }
    }
    progress.currentEmail = null;
    progress.stage = "next";
    progress.screenshotPath = null;
    progress.waitUntil = null;
    progress.mainSurveyHttpStatus = null;
    progress.failureScreenshotPath = null;
    progress.diagnosticPath = null;
    saveProgress(progress);
    console.warn("Blocking checkpoint cleared. Continuing with the next available email.");
    console.warn("────────────────────────────────────────────────────────");
  }

  if (singleForm) {
    const users = uniqueEmails(loadUsers());
    singleDone = loadState();
    usedEmails = loadUsedEmails();
    if (progress.currentEmail && !users.some((user) => user.email.toLowerCase() === progress.currentEmail.toLowerCase()) &&
      !["dashboard", "main_submit_started", "dashboard_saved"].includes(progress.stage)) {
      console.warn(`Checkpoint email ${progress.currentEmail} is not in the CSV and has no confirmed main submission.`);
      console.warn("Clearing checkpoint and continuing with the next available email.");
      try {
        const filePath = abs("data/unconfirmed-emails.json");
        let records = [];
        try {
          records = JSON.parse(fs.readFileSync(filePath, "utf8"));
          if (!Array.isArray(records)) records = [];
        } catch {}
        if (!records.some((entry) => String(entry.email || "").toLowerCase() === progress.currentEmail.toLowerCase())) {
          records.push({
            email: progress.currentEmail,
            stage: progress.stage,
            screenshotPath: progress.screenshotPath || null,
            reason: "Checkpoint email absent from CSV; recovered at startup",
            at: new Date().toISOString(),
          });
          fs.writeFileSync(filePath, JSON.stringify(records, null, 2));
        }
      } catch {}
      progress.currentEmail = null;
      progress.stage = "next";
      progress.screenshotPath = null;
      progress.waitUntil = null;
      progress.mainSurveyHttpStatus = null;
      saveProgress(progress);
    }
    if (progress.currentEmail && singleDone.has(progress.currentEmail.toLowerCase())) {
      progress.currentEmail = null;
      progress.stage = "next";
      progress.screenshotPath = null;
      saveProgress(progress);
    }
    const unconfirmedEmails = loadUnconfirmedEmails();
    const alreadyUsed = new Set([...singleDone, ...usedEmails, ...unconfirmedEmails].map((email) => email.toLowerCase()));
    const usedCount = users.filter((user) => alreadyUsed.has(user.email.toLowerCase())).length;

    if (progress.currentEmail) {
      singleTodo = selectEmailCandidates(users, {
        alreadyUsed,
        unconfirmed: unconfirmedEmails,
        currentEmail: progress.currentEmail,
        limit,
      });
    } else if (emailOverride) {
      if (alreadyUsed.has(emailOverride.toLowerCase())) {
        console.log(`Email ${emailOverride} was already used; it will not be reused.`);
        console.log(`Total unique emails used: ${usedCount}.`);
        return;
      }
      const csvEmail = users.find((user) => user.email.toLowerCase() === emailOverride.toLowerCase());
      if (!csvEmail) {
        console.log(`Email ${emailOverride} is not present in the configured CSV; only CSV emails can be used.`);
        return;
      }
      singleTodo = [csvEmail];
    } else {
      singleTodo = selectEmailCandidates(users, {
        alreadyUsed,
        unconfirmed: unconfirmedEmails,
        limit,
      });
    }

    if (!singleTodo.length) {
      await waitUntil(progress.waitUntil);
      progress.waitUntil = null;
      saveProgress(progress);
      console.log("No unused emails are left in the CSV.");
      console.log(`Total unique emails used to fill the form: ${usedCount}.`);
      return;
    }
    if (!dry) validateDashboardConfig();
  }

  const { browser, context } = singleForm
    ? await retryForever("Browser launch", openBrowser)
    : await openBrowser();

  // Sequential one-form mode: handle pending CSV emails one at a time.
  if (singleForm) {
    try {
      const done = singleDone;
      const skipped = [];
      const startCycles = progress.completedCycles;
      const emailSelector = cfg.form.emailSelector || 'input[type="email"]';
      if (!cfg.form.submitSelector || String(cfg.form.submitSelector).includes("PASTE_")) {
        throw new Error("Set form.submitSelector in flow.config.json before running the one-form flow.");
      }
      console.log(`Processing ${singleTodo.length} email(s) sequentially${dry ? " | DRY RUN" : ""}`);

      await runSelectedEmails(singleTodo, async (user) => {
        const email = user.email;
        const id = slug(email);
        await waitUntil(progress.waitUntil);
        progress.waitUntil = null;
        if (!progress.currentEmail) {
          progress.currentEmail = email;
          progress.stage = "main";
          progress.screenshotPath = null;
          usedEmails.add(email.toLowerCase());
          saveUsedEmails(usedEmails);
          saveProgress(progress);
        }

        let outputPath = progress.screenshotPath;
        if (!outputPath) {
          if (screenshotOverride) {
            const parsed = path.parse(screenshotOverride);
            const customName = parsed.name.includes("{email}")
              ? parsed.name.replace("{email}", id)
              : `${parsed.name}_${id}`;
            outputPath = abs(path.join(parsed.dir, `${customName}${parsed.ext || ".png"}`));
          } else {
            outputPath = abs(`screenshots/${id}_filled.png`);
          }
          progress.screenshotPath = outputPath;
          saveProgress(progress);
        }

        const page = await retryForever("Browser page", () => context.newPage());
        try {
          console.log(`\n→ Current email | stage: ${progress.stage}`);
          const mainTemplatePath = templateOverride || cfg.templatePath || "data/answers.template.json";
          const answers = loadAndResolve(mainTemplatePath);

          if (!["dashboard", "main_submit_started", "dashboard_saved"].includes(progress.stage)) {
            await retryForever("Main form fill", async () => {
              console.log("  Opening main form URL...");
              await page.goto(formUrl, { waitUntil: "domcontentloaded" });
              console.log("  Main form loaded; filling email field...");
              await page.locator("body").waitFor();
              await page.waitForSelector('iframe[src*="form.html"]', { state: "attached" });
              const formFrame = page.frameLocator('iframe[src*="form.html"]');
              try { await page.locator("#cookiescript_reject").click({ timeout: 3000 }); } catch {}
              await formFrame.locator(emailSelector).first().fill(email);
              console.log("  Email filled; resolving and filling template answers...");
              await autoFill(formFrame, answers, mainTemplatePath, cfg.form.fields || {}, cfg.form.ratingFields || null);
              console.log("  Answers filled; capturing screenshot crop...");
              fs.mkdirSync(path.dirname(outputPath), { recursive: true });
              await takeEmailSubmitShot(page, emailSelector, cfg.form.submitSelector, outputPath, formFrame);
              console.log("  Screenshot saved.");
            });
            progress.stage = "main_ready";
            saveProgress(progress);

            if (dry) {
              console.log("[dry] Filled and captured the current email; it remains reserved and will not be reused.");
              progress.currentEmail = null;
              progress.stage = "next";
              progress.screenshotPath = null;
              progress.waitUntil = null;
              saveProgress(progress);
              return;
            }
          }

          const cycleResult = await runConfirmedCycle({
            submitMain: async () => {
              if (["dashboard", "main_submit_started", "dashboard_saved"].includes(progress.stage)) {
                return { status: "confirmed", resumed: true };
              }
              progress.stage = "main_submit_unconfirmed";
              saveProgress(progress);
              const configuredOrigin = new URL(formUrl).origin;
              const formFrame = page.frames().find((frame) => {
                try {
                  const frameUrl = new URL(frame.url());
                  return frameUrl.origin === configuredOrigin && frameUrl.pathname.includes("form.html");
                } catch {
                  return false;
                }
              });
              if (!formFrame) return { status: "uncertain", response: null, reason: "survey_form_frame_missing" };

              const outcome = await submitMainOnce({
                page,
                formFrame,
                submitSelector: cfg.form.submitSelector,
                formUrl,
              });
              console.log(`  Main survey outcome: ${outcome.status}${outcome.response ? ` | HTTP ${outcome.response.status()}` : ""}`);
              if (outcome.status === "confirmed") {
                progress.stage = "main_submit_started";
                progress.waitUntil = Date.now() + (cfg.form.afterSubmitWaitMs ?? 30000);
                saveProgress(progress);
                console.log("Main survey confirmed; keeping the confirmation page open during the configured wait.");
              }
              return outcome;
            },
            waitAfterSubmit: async () => {
              await waitUntil(progress.waitUntil);
              progress.waitUntil = null;
              saveProgress(progress);
            },
            saveDashboard: async () => {
              if (progress.stage !== "dashboard_saved") {
                if (progress.dashboardSaveStarted) {
                  const blocked = new Error(`A dashboard Save was already started for ${email} and its outcome is unknown. Verify in the dashboard (All Submissions), then set dashboardSaveStarted to null (or stage to dashboard_saved if it exists) in data/flow-progress.json.`);
                  blocked.stopBatch = true;
                  throw blocked;
                }
                await retryForever(`Dashboard submission for ${email}`, () => {
                  if (progress.stage === "dashboard_saved") return Promise.resolve();
                  return uploadProof(page, email, outputPath, () => {
                    progress.stage = "dashboard_saved";
                    saveProgress(progress);
                  }, () => {
                    progress.dashboardSaveStarted = true;
                    saveProgress(progress);
                  });
                });
              }
              console.log("Dashboard submission saved.");
            },
            markProcessed: async () => {
              progress.completedCycles += 1;
              progress.dashboardSaveStarted = null;
              progress.currentEmail = null;
              progress.stage = "next";
              progress.screenshotPath = null;
              const cycleGap = progress.completedCycles % 100 === 0 ? 60000 : Math.floor(30000 + Math.random() * 30001);
              progress.waitUntil = Date.now() + cycleGap;
              saveProgress(progress);
              done.add(email.toLowerCase());
              saveState(done);
              console.log(`Completed cycle ${progress.completedCycles}; waiting ${Math.round(cycleGap / 1000)} seconds before the next email.`);
              await waitUntil(progress.waitUntil);
              progress.waitUntil = null;
              saveProgress(progress);
            },
          });

          if (cycleResult.status !== "completed") {
            await persistMainFailure(page, email, progress, answers, cycleResult);
            const failure = new Error(`Main survey ${cycleResult.status}; email left unconfirmed and will be skipped.`);
            failure.skipEmail = true;
            // Uncertain/rejected/forbidden alike: evidence is saved above, the email is skipped (never resubmitted), batch continues.
            throw failure;
          }
        } catch (err) {
          // Never halt the whole batch on main-survey 403/uncertain/rejected.
          // Record evidence, clear checkpoint, continue with next email.
          // Only Ctrl+C should stop the process.
          console.error(`  FAIL: ${err.message}`);
          await page.screenshot({ path: abs(`screenshots/${id}_error.png`), fullPage: true }).catch(() => {});
          if (err.stopBatch) {
            console.error(`  STOPPING: main survey outcome uncertain for ${email}. Checkpoint (stage ${progress.stage}) and evidence preserved; not skipping, not resubmitting. Verify manually, then decide.`);
            throw err;
          }
          skipped.push({ email, stage: progress.stage, reason: err.message });
          const unconfirmedFile = abs("data/unconfirmed-emails.json");
          let unconfirmed = [];
          try { unconfirmed = JSON.parse(fs.readFileSync(unconfirmedFile, "utf8")); } catch {}
          if (!unconfirmed.some((entry) => String(entry.email || "").toLowerCase() === email.toLowerCase())) {
            unconfirmed.push({
              email,
              stage: progress.stage,
              screenshotPath: progress.screenshotPath,
              reason: err.message,
              status: progress.mainSurveyHttpStatus || null,
              at: new Date().toISOString(),
            });
            fs.writeFileSync(unconfirmedFile, JSON.stringify(unconfirmed, null, 2));
          }
          progress.currentEmail = null;
          progress.stage = "next";
          progress.screenshotPath = null;
          progress.waitUntil = null;
          progress.mainSurveyHttpStatus = null;
          progress.failureScreenshotPath = null;
          progress.diagnosticPath = null;
          saveProgress(progress);
          console.error(`  Skipping ${email}; continuing with the next email.`);
        } finally {
          await page.close();
        }
      });
      console.log(`\nRun summary: processed ${progress.completedCycles - startCycles}, skipped/unconfirmed ${skipped.length}.`);
      for (const entry of skipped) console.log(`  skipped: ${entry.email} (stage ${entry.stage}) - ${entry.reason}`);
      const unavailable = new Set([...done, ...usedEmails].map((email) => email.toLowerCase()));
      const remaining = uniqueEmails(loadUsers()).filter((user) => !unavailable.has(user.email.toLowerCase()));
      if (!remaining.length) {
        console.log("No unused emails are left in the CSV.");
        const usedCount = uniqueEmails(loadUsers()).filter((user) => unavailable.has(user.email.toLowerCase())).length;
        console.log(`Total unique emails used to fill the form: ${usedCount}.`);
      }
    } finally {
      await browser.close();
    }
    return;
  }

  const all = uniqueEmails(loadUsers());
  const done = loadState();
  const used = loadUsedEmails();
  const unconfirmed = loadUnconfirmedEmails();
  const unavailable = new Set([...done, ...used, ...unconfirmed].map((email) => email.toLowerCase()));
  const todo = all.filter((u) => !unavailable.has(u.email.toLowerCase())).slice(0, limit);

  console.log(`Total ${all.length} | pending ${todo.length}${dry ? " | DRY RUN" : ""}`);
  if (!todo.length) {
    console.log("No unused emails are left in the CSV.");
    console.log(`Total unique emails used to fill the form: ${all.filter((user) => unavailable.has(user.email.toLowerCase())).length}.`);
    await browser.close();
    return;
  }

  // One-time logins (session stays in context)
  {
    const p = await context.newPage();
    await login(p, cfg.form.login, "FORM_USER", "FORM_PASS");
    if (!dry && cfg.dashboard?.enabled) {
      await login(p, cfg.dashboard.login, "DASH_USER", "DASH_PASS");
      dashboardLoginDone = true;
    }
    await p.close();
  }

  for (const user of todo) {
    const email = user.email;
    const id = slug(email);
    const page = await context.newPage();

    try {
      // Fresh resolved answers for every submission (so random picks stay unique)
      const mainTemplatePath = templateOverride || cfg.templatePath || "data/answers.template.json";
      const answers = loadAndResolve(mainTemplatePath);
      console.log(`\n→ ${email}`);

      await page.goto(formUrl, { waitUntil: "networkidle" });

      // Email field
      used.add(email.toLowerCase());
      saveUsedEmails(used);
      await page.fill(cfg.form.emailSelector, email);

      // Normal mapped fields
      for (const [key, def] of Object.entries(cfg.form.fields || {})) {
        if (key === "COMMENT" || !def.selector || String(def.selector).includes("PASTE_")) continue;
        const value = answers[key] ?? answers[`q${key}`];
        if (value !== undefined) {
          await fillField(page, def, value);
        }
      }

      // Rating fields (optional bulk)
      if (cfg.form.ratingFields && cfg.form.ratingFields.ids) {
        const rf = cfg.form.ratingFields;
        for (const qid of rf.ids) {
          const value = answers[`q${qid}`] ?? answers._ratingDefault ?? "5";
          const selector = rf.selectorPattern.replace("{id}", qid);
          try {
            await fillField(page, { selector, type: rf.type || "radio" }, value);
          } catch {
            // field may not exist on this form version
          }
        }
      }

      // Screenshot of filled state (email + submit area if configured)
      const filledPath = abs(`screenshots/${id}_filled.png`);
      await takeShot(page, filledPath);
      console.log(`  shot → ${path.relative(process.cwd(), filledPath)}`);

      if (dry) {
        console.log(`  [dry] submit skipped`);
        continue;
      }

      await page.click(cfg.form.submitSelector);
      await page.waitForTimeout(cfg.form.afterSubmitWaitMs || 2000);

      const submittedPath = abs(`screenshots/${id}_submitted.png`);
      await takeShot(page, submittedPath);

      // Upload proof to your dashboard
      await uploadProof(page, email, filledPath);

      done.add(email.toLowerCase());
      saveState(done);
      console.log(`  OK`);
    } catch (err) {
      console.error(`  FAIL: ${err.message}`);
      await page
        .screenshot({ path: abs(`screenshots/${id}_error.png`), fullPage: true })
        .catch(() => {});
    } finally {
      await page.close();
    }
  }

  const unavailableAfterRun = new Set([...done, ...used].map((email) => email.toLowerCase()));
  const remaining = all.filter((user) => !unavailableAfterRun.has(user.email.toLowerCase()));
  if (!remaining.length) {
    console.log("No unused emails are left in the CSV.");
    console.log(`Total unique emails used to fill the form: ${all.filter((user) => unavailableAfterRun.has(user.email.toLowerCase())).length}.`);
  }

  await browser.close();
  console.log("\nDone.");
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
