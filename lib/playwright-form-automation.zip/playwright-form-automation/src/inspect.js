const { cfg } = require("./config");
const { openBrowser } = require("./browser");

(async () => {
  const url = process.argv[2] || cfg.form.url;
  if (!url || url.includes("PASTE_")) {
    console.error("Pass a real URL:  npm run inspect -- https://your-form-url");
    process.exit(1);
  }

  const { browser, context } = await openBrowser();
  const page = await context.newPage();
  await page.goto(url, { waitUntil: "networkidle" });

  for (const frame of page.frames()) {
    const items = await frame.evaluate(() =>
      [...document.querySelectorAll("input, select, textarea, button")].map((el) => ({
        tag: el.tagName.toLowerCase(),
        type: el.type || "",
        name: el.name || "",
        id: el.id || "",
        value: el.type === "radio" || el.type === "checkbox" ? el.value : "",
        label: (el.labels?.[0]?.innerText || el.placeholder || el.innerText || "")
          .trim()
          .slice(0, 70),
      }))
    );
    console.log(`\n== frame: ${frame.url()} (${items.length} controls)`);
    console.table(items);
  }

  await page.screenshot({ path: "screenshots/inspection.png", fullPage: true });
  console.log("\nScreenshot → screenshots/inspection.png");
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
